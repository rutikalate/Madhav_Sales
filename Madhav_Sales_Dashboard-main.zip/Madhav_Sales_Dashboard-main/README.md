# PowerBi_dashboard_project
This is a power bi end to end project

## Watch complete Power BI tutorial video here: https://www.youtube.com/watch?v=6cV3OwFrOkk

Hope you like this video! :)
